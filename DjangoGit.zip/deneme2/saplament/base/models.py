
from django.db import models
from django.contrib.auth.models import User
from django.shortcuts import reverse
# Create your models here.


LABEL_CHOICES= (
    ('P','primary'),
    ('S','secondary'),
    ('D','danger'),
)


    
class categories(models.Model):

    category_name=models.CharField(max_length=200)
    slug=models.SlugField(null=True)
    def __str__(self):
        return self.category_name
    
class Products(models.Model):
    title = models.CharField(max_length=200, verbose_name='Ürün Adı')
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='Ürün Fiyatı')
    category = models.ForeignKey(categories, on_delete=models.CASCADE)
    urun_desc = models.CharField(max_length=200, verbose_name='Ürün Açıklaması')
    urun_foto = models.ImageField(max_length=200, verbose_name='Ürün Fotoğraf')
    slug = models.SlugField()
    

    def __str__(self):
        return self.title
    
    def get_absolute_url(self):
        return reverse("views.product/", kwargs={
        'slug': self.slug
    })

    def get_add_to_cart_url(self):
        return reverse("/add-to-cart/", kwargs={
        'slug': self.slug
    })


class Cart(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    start_date = models.DateTimeField(auto_now_add=True)
    ordered_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return '{0}\'in sepeti'.format(self.user)


class CartItem(models.Model):
    item = models.ForeignKey(Products, related_name='CartItems', on_delete=models.CASCADE)

    cart = models.ForeignKey(Cart, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)

    total_price = models.DecimalField(max_digits=10,
                                      blank=True,
                                      null=True,
                                      decimal_places=2,
                                      verbose_name='Total Fiyat',
                                      )

    def __str__(self):
        return f"{self.quantity} of {self.item.title}"

class Address(models.Model):
    user=models.OneToOneField(User, on_delete=models.CASCADE,null=True)
    phone=models.CharField(max_length=200,null=True)
    address = models.CharField(max_length=200,null=True)
    city=models.CharField(max_length=200,null=True)
    region=models.CharField(max_length=200,null=True)
    zip_code=models.CharField(max_length=200,null=True)
    country=models.CharField(max_length=200,null=True)




class Order(models.Model):

    user=models.OneToOneField(User,on_delete=models.CASCADE,null=True)


    def __str__(self):
        return '{0}\'in siparişi'.format(self.user)


class OrderItem(models.Model):
    cart=models.OneToOneField(Cart,on_delete=models.CASCADE,null=True)
    ordered_date=models.DateTimeField(auto_now_add=True,null=True)
    order = models.ForeignKey(Order, on_delete=models.CASCADE, null=True)











class FooterURL(models.Model):
    title = models.CharField(max_length=200,null=True, verbose_name='Adı')
    url = models.URLField(max_length=200)

    def __str__(self):
        return self.title





class Iletisim(models.Model):


    name=models.CharField(max_length=300,null=True,verbose_name='Alan Adı')
    field=models.CharField(max_length=300,null=True,verbose_name='Alan')
    icon=models.CharField(max_length=200,null=True, verbose_name='İKON')
    def __str__(self):
        return self.name

class Hakkimizda(models.Model):
    name = models.CharField(max_length=300, null=True, verbose_name='Alan Adı')
    field = models.CharField(max_length=300, null=True, verbose_name='Alan')
    url = models.URLField(max_length=200, null=True,blank=True)
    def __str__(self):
        return self.name




