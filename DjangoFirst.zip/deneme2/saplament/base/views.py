
from django.utils import timezone
from django.db.models import Count

from django.db.models import Sum
import re
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect,render,get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from django.contrib import messages

from django.core.paginator import Paginator


from django.contrib.auth.models import User
# Create your views here.
from .models import (
    Item,
    categories,
    CartItem,
    OrderItem,
    FooterURL,
    Iletisim,
    Hakkimizda,

)




def count (request):
    if request.user.is_authenticated:
        q = OrderItem.objects.filter(user=request.user).annotate(Count('quantity'))
        result = 0

        for x in range(0,q.count()):
            res = "".join([ele for ele in str(q[x])[0:3] if ele.isdigit()])
            _int1=int(res)

            result= result+_int1


    else :
        result = '0' # burayı düzelt
    return result


def hakkimizda():
    hakkimizda=Hakkimizda.objects.all().values()
    return hakkimizda

def footer():
    footer= FooterURL.objects.all().values()
    return footer
def iletisim():
    iletisim = Iletisim.objects.all().values()
    return iletisim

def index(request):

    product = Item.objects.all().values()
    category = categories.objects.all().values()
    #template = loader.get_template('index.html')
    toplam=0
    p=Paginator(product,per_page=4)
    page = request.GET.get('page')
    products = p.get_page(page)

    context={
        'product': product,
        'products':products,
        'category': category,
        'count': count(request),
        'url':footer(),
        'iletisim': iletisim(),
        'hakkimizda':hakkimizda(),
    }
    return  render(request, 'index.html', context) #HttpResponse(template.render(context,request))




#Category


def category(request,slug):

    product =Item.objects.filter(category__slug=slug)
    p = Paginator(product, per_page=1)
    page = request.GET.get('page')
    products = p.get_page(page)
    template=loader.get_template('category.html')
    context={
        'category':categories.objects.all().values(),
        'products':products,
        'url': footer(),
        'count': count(request),
        'iletisim': iletisim(),
    }
    return HttpResponse(template.render(context,request))


def cart(request):
    product = Item.objects.all()
    item = OrderItem.objects.filter(user=request.user)

    cart_sum=OrderItem.objects.filter(user=request.user).aggregate(
        Sum('item__price', field='item__price  * quantity')).get('item__price__sum')
    print(cart_sum)# ürünlerin fiyatını topluyor adeti 1 olarak alıyor
    context = {
        'item': item,
        'product': product,
        'count': count(request),
        'url': footer(),
        'iletisim': iletisim(),
    }
    return render(request,'apps/cart.html',context)



@login_required
def add_to_cart(request, slug):
    item = get_object_or_404(Item, slug=slug)
    order_item, created = OrderItem.objects.get_or_create(
        item=item,
        user=request.user,
        ordered=False
    )
    order_qs = CartItem.objects.filter(user=request.user, ordered=False)
    if order_qs.exists():
        order = order_qs[0]
        # check if the order item is in the order
        if order.items.filter(item__slug=item.slug).exists():
            order_item.quantity += 1
            order_item.save()
            messages.info(request, "This item quantity was updated.")
            return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
        else:
            order.items.add(order_item)
            messages.info(request, "This item was added to your cart.")
            return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
    else:
        ordered_date = timezone.now()
        order = CartItem.objects.create(
            user=request.user, ordered_date=ordered_date)
        order.items.add(order_item)
        messages.info(request, "This item was added to your cart.")
        return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))


@login_required
def remove_from_cart(request, slug):
    item = get_object_or_404(Item, slug=slug)
    order_qs = CartItem.objects.filter(
        user=request.user,
        ordered=False
    )
    if order_qs.exists():
        order = order_qs[0]
        # check if the order item is in the order
        if order.items.filter(item__slug=item.slug).exists():
            order_item = OrderItem.objects.filter(
                item=item,
                user=request.user,
                ordered=False
            )[0]
            order.items.remove(order_item)
            order_item.delete()
            messages.info(request, "This item was removed from your cart.")
            return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
        else:
            messages.info(request, "This item was not in your cart")
            return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.info(request, "You do not have an active order")
        return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))


@login_required
def remove_single_item_from_cart(request, slug):
    item = get_object_or_404(Item, slug=slug)
    order_qs = CartItem.objects.filter(
        user=request.user,
        ordered=False
    )
    if order_qs.exists():
        order = order_qs[0]
        # check if the order item is in the order
        if order.items.filter(item__slug=item.slug).exists():
            order_item = OrderItem.objects.filter(
                item=item,
                user=request.user,
                ordered=False
            )[0]
            if order_item.quantity > 1:
                order_item.quantity -= 1
                order_item.save()
            else:
                order.items.remove(order_item)
            messages.info(request, "This item quantity was updated.")
            return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
        else:
            messages.info(request, "This item was not in your cart")
            return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.info(request, "You do not have an active order")
        return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))





def deleteCart(request,slug):
    product=Item.objects.get(slug=slug)
    cart_item= OrderItem.objects.filter(item=product)
    cart_item.delete()
    return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))

def product(request):
    context={

    }
    return  render(request, 'index.html', context)





def product_update(request):
    product = Item.objects.all().values()
    template = loader.get_template('apps/product-update.html')
    context = {
        'product': product,
    }
    return HttpResponse(template.render(context,request))







# def table(request):
#     product = products.objects.all().values()
#     category= categories.objects.all().values()
#     template= loader.get_template('apps/table.html')
#     context = {
#         'product': product, 'category':category
#     }
#     return HttpResponse(template.render(context,request))




# def dashboard(request):
#     template = loader.get_template('dashboard/dashboard.html')
#     context={
#     }
#     return HttpResponse(template.render(context,request))








# #Productt


# def add(request):
#     template = loader.get_template('apps/add.html')
#     return HttpResponse(template.render({},request))



# def addRecord(request):
#     urunAdi= request.POST['urunAdi']
#     urunFiyat = request.POST['urunFiyat']
#     categoryID= request.POST['categoryID']
#     urunDesc = request.POST['urunDesc']
#     urunFoto = request.POST['urunFoto']
#     #foto copy
#     path="C:\\Users\\mehme\\Desktop\\fotoEkleme\\"+urunFoto
#     destination ="C:\\Users\\mehme\\Desktop\\djangoDeneme\\saplament\\base\\static\\images\\"+urunFoto
#     shutil.copyfile(path,destination)

#     product = products(
#         urun_adi=urunAdi,
#         urun_fiyat=urunFiyat,
#         category_name=categoryID,
#         urun_desc=urunDesc,
#         urun_foto=urunFoto

#     )
#     product.save()
#     messages.info(request, 'Added successfully!')
#     return HttpResponseRedirect(reverse('add'))

# def update(request,id):
#     product = products.objects.get(id=id)
#     template = loader.get_template('apps/update.html')
#     context = {
#         'product':product
#     }
#     return HttpResponse(template.render(context,request))

# def updateRecord(request,id):
    
#     product = products.objects.get(id=id)
#     urunAdi=request.POST['urunAdi']
#     urunFiyat=request.POST['urunFiyat']
#     urunCategory=request.POST['categoryID']
#     urunDesc=request.POST['urunDesc']
#     urunFoto= request.POST['urunFoto']
#     product.urun_adi=urunAdi
#     product.urun_fiyat=urunFiyat
#     product.category_name=urunCategory
#     product.urun_desc = urunDesc
#     product.urun_foto=urunFoto
#     try:
#     #copy foto
#         path="C:\\Users\\mehme\\Desktop\\fotoEkleme\\"+urunFoto
#         destination ="C:\\Users\\mehme\\Desktop\\djangoDeneme\\saplament\\base\\static\\images\\"+urunFoto
#         shutil.copyfile(path,destination)
#     except:
#         print('')
#     product.save()
#     return HttpResponseRedirect(reverse('index'))
   




# def delete(request,id):
#     product = products.objects.get(id=id)
#     product.delete()
#     return HttpResponseRedirect(reverse('table'))




# def addCategory(request):
#     template = loader.get_template('apps/add-category.html')
#     return HttpResponse(template.render({},request))


# def addCategoryRecord(request):
#     categoryName= request.POST['categoryName']
#     category = categories(
#         category_name=categoryName

#     )
#     category.save()
#     return HttpResponseRedirect(reverse('table'))

# def categoryUpdate(request,id):
#     category = categories.objects.get(id=id)
#     template = loader.get_template('apps/update-category.html')
#     context = {
#         'category':category
#     }
#     return HttpResponse(template.render(context,request))


# def categoryUpdateRecord(request,id):
#     category = categories.objects.get(id=id)
#     catID = request.POST['catID']
#     categoryName=request.POST['categoryName']
#     category.delete()
#     category.category_name=categoryName
#     category.id=catID
#     category.save()
#     return HttpResponseRedirect(reverse('table'))


# def categoryDelete(request,id):
#     category = categories.objects.get(id=id)
#     category.delete()
#     return HttpResponseRedirect(reverse('table'))




