from tkinter import CASCADE
from django.db import models

# Create your models here.





    
class categories(models.Model):
    category_name=models.CharField(max_length=200)
    
class products(models.Model):
    urun_adi = models.CharField(max_length=200, verbose_name='Ürün Adı')
    urun_fiyat = models.DecimalField(max_digits=10,decimal_places=2, verbose_name='Ürün Fiyatı')
    category_name = models.BigIntegerField(verbose_name='Kategori id')
    urun_desc = models.CharField(max_length=200, verbose_name='Ürün Açıklaması')
    urun_foto = models.CharField(max_length=200, verbose_name='Ürün Fotoğraf')
    

    def __str__(self):
        return self.urun_adi


class cart_items(models.Model):
    urun_id= models.ForeignKey(products,on_delete=models.CASCADE)
    urun_adet= models.BigIntegerField()
    