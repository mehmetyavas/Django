from django.contrib import admin

from .models import *

# Register your models here.


class ItemAdmin(admin.ModelAdmin):
    list_display=('id','title','price','category','urun_desc')
    list_display_links=('id','title')
    search_fields = ('title','urun_desc')
    list_per_page= 10
    list_filter = ('category','price')
class CategoryAdmin(admin.ModelAdmin):
    list_display=('id','slug')
    list_display_links=('id','slug')
    list_per_page= 10

class OrderItemAdmin(admin.ModelAdmin):
    list_display = ('id','item', 'quantity','user')


admin.site.register(OrderItem,OrderItemAdmin)
admin.site.register(Item, ItemAdmin)
admin.site.register(categories,CategoryAdmin)
admin.site.register(CartItem)

admin.site.register(FooterURL)
admin.site.register(Iletisim)
admin.site.register(Hakkimizda)
admin.site.index_title = 'deneme'