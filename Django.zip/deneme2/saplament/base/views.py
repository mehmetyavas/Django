from django.shortcuts import redirect,render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from django.contrib import messages
# Create your views here.
from .models import products, categories,cart_items
import shutil


def index(request):
    product = products.objects.all().values()
    category = categories.objects.all().values()
    #template = loader.get_template('index.html')
    print(cart_items.objects.count())
    context={
        'product':product,
         'category':category,
         'count':cart_items.objects.count()
    }
    return  render(request,'index.html',context) #HttpResponse(template.render(context,request))


def product_update(request):
    product = products.objects.all().values()
    template = loader.get_template('apps/product-update.html')
    context={
        'product':product,
    }
    return HttpResponse(template.render(context,request))


#Category


def category(request):
    category = categories.objects.all()
    print(request.GET)
    query_dict=request.GET
    try:
        query = int(query_dict.get("q"))
    except:
        query= None
    product=None
    if query is not None:
        print(query)
        product =products.objects.filter(category_name=query)
    template=loader.get_template('category.html')
    context={
        'category':category,
        'product':product,
    }
    
    return HttpResponse(template.render(context,request))




def cartItems(request,id):
    product=products.objects.get(id=id)
    cart_item = cart_items(
        urun_id=product,
        urun_adet=1,

     )
    cart_item.save()
    
    
    
    return redirect('index')




# def table(request):
#     product = products.objects.all().values()
#     category= categories.objects.all().values()
#     template= loader.get_template('apps/table.html')
#     context = {
#         'product': product, 'category':category
#     }
#     return HttpResponse(template.render(context,request))




# def dashboard(request):
#     template = loader.get_template('dashboard/dashboard.html')
#     context={
#     }
#     return HttpResponse(template.render(context,request))








# #Productt


# def add(request):
#     template = loader.get_template('apps/add.html')
#     return HttpResponse(template.render({},request))



# def addRecord(request):
#     urunAdi= request.POST['urunAdi']
#     urunFiyat = request.POST['urunFiyat']
#     categoryID= request.POST['categoryID']
#     urunDesc = request.POST['urunDesc']
#     urunFoto = request.POST['urunFoto']
#     #foto copy
#     path="C:\\Users\\mehme\\Desktop\\fotoEkleme\\"+urunFoto
#     destination ="C:\\Users\\mehme\\Desktop\\djangoDeneme\\saplament\\base\\static\\images\\"+urunFoto
#     shutil.copyfile(path,destination)

#     product = products(
#         urun_adi=urunAdi,
#         urun_fiyat=urunFiyat,
#         category_name=categoryID,
#         urun_desc=urunDesc,
#         urun_foto=urunFoto

#     )
#     product.save()
#     messages.info(request, 'Added successfully!')
#     return HttpResponseRedirect(reverse('add'))

# def update(request,id):
#     product = products.objects.get(id=id)
#     template = loader.get_template('apps/update.html')
#     context = {
#         'product':product
#     }
#     return HttpResponse(template.render(context,request))

# def updateRecord(request,id):
    
#     product = products.objects.get(id=id)
#     urunAdi=request.POST['urunAdi']
#     urunFiyat=request.POST['urunFiyat']
#     urunCategory=request.POST['categoryID']
#     urunDesc=request.POST['urunDesc']
#     urunFoto= request.POST['urunFoto']
#     product.urun_adi=urunAdi
#     product.urun_fiyat=urunFiyat
#     product.category_name=urunCategory
#     product.urun_desc = urunDesc
#     product.urun_foto=urunFoto
#     try:
#     #copy foto
#         path="C:\\Users\\mehme\\Desktop\\fotoEkleme\\"+urunFoto
#         destination ="C:\\Users\\mehme\\Desktop\\djangoDeneme\\saplament\\base\\static\\images\\"+urunFoto
#         shutil.copyfile(path,destination)
#     except:
#         print('')
#     product.save()
#     return HttpResponseRedirect(reverse('index'))
   




# def delete(request,id):
#     product = products.objects.get(id=id)
#     product.delete()
#     return HttpResponseRedirect(reverse('table'))




# def addCategory(request):
#     template = loader.get_template('apps/add-category.html')
#     return HttpResponse(template.render({},request))


# def addCategoryRecord(request):
#     categoryName= request.POST['categoryName']
#     category = categories(
#         category_name=categoryName

#     )
#     category.save()
#     return HttpResponseRedirect(reverse('table'))

# def categoryUpdate(request,id):
#     category = categories.objects.get(id=id)
#     template = loader.get_template('apps/update-category.html')
#     context = {
#         'category':category
#     }
#     return HttpResponse(template.render(context,request))


# def categoryUpdateRecord(request,id):
#     category = categories.objects.get(id=id)
#     catID = request.POST['catID']
#     categoryName=request.POST['categoryName']
#     category.delete()
#     category.category_name=categoryName
#     category.id=catID
#     category.save()
#     return HttpResponseRedirect(reverse('table'))


# def categoryDelete(request,id):
#     category = categories.objects.get(id=id)
#     category.delete()
#     return HttpResponseRedirect(reverse('table'))




