from django.contrib import admin

from .models import *
# Register your models here.


class ProductAdmin(admin.ModelAdmin):
    list_display=('id','urun_adi','urun_fiyat','category_name','urun_desc')
    list_display_links=('id','urun_adi')
    search_fields = ('urun_adi','urun_desc')
    list_per_page= 10

class CategoryAdmin(admin.ModelAdmin):
    list_display=('id','category_name')
    list_display_links=('id','category_name')
    list_per_page= 10



admin.site.register(products,ProductAdmin)
admin.site.register(categories,CategoryAdmin)
admin.site.register(cart_items)