
from django.db import models
from django.contrib.auth.models import User
from django.shortcuts import reverse
# Create your models here.


LABEL_CHOICES= (
    ('P','primary'),
    ('S','secondary'),
    ('D','danger'),
)


    
class categories(models.Model):

    category_name=models.CharField(max_length=200)
    slug=models.SlugField(null=True)
    def __str__(self):
        return self.category_name
    
class Item(models.Model):
    title = models.CharField(max_length=200, verbose_name='Ürün Adı')
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='Ürün Fiyatı')
    category_name = models.BigIntegerField(verbose_name='Kategori id')
    category = models.ForeignKey(categories, on_delete=models.CASCADE)
    urun_desc = models.CharField(max_length=200, verbose_name='Ürün Açıklaması')
    urun_foto = models.ImageField(max_length=200, verbose_name='Ürün Fotoğraf')
    slug = models.SlugField()
    

    def __str__(self):
        return self.title
    
    def get_absolute_url(self):
        return reverse("views.product/", kwargs={
        'slug': self.slug
    })

    def get_add_to_cart_url(self):
        return reverse("/add-to-cart/", kwargs={
        'slug': self.slug
    })



class OrderItem(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    ordered = models.BooleanField(default=False)
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    total_price=models.DecimalField(max_digits=10,blank=True, null=True,decimal_places=2, verbose_name='Total Fiyat')


    def __str__(self):
        return f"{self.quantity} of {self.item.title}"


class CartItem(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    items = models.ManyToManyField(OrderItem, null=True)
    start_date = models.DateTimeField(auto_now_add=True)
    ordered_date = models.DateTimeField(auto_now_add=True)
    ordered = models.BooleanField(default=False)

    def __str__(self):
        return str(self.user)





class FooterURL(models.Model):
    title = models.CharField(max_length=200,null=True, verbose_name='Adı')
    url = models.URLField(max_length=200)

    def __str__(self):
        return self.title





class Iletisim(models.Model):


    name=models.CharField(max_length=300,null=True,verbose_name='Alan Adı')
    field=models.CharField(max_length=300,null=True,verbose_name='Alan')
    icon=models.CharField(max_length=200,null=True, verbose_name='İKON')
    def __str__(self):
        return self.name

class Hakkimizda(models.Model):
    name = models.CharField(max_length=300, null=True, verbose_name='Alan Adı')
    field = models.CharField(max_length=300, null=True, verbose_name='Alan')
    url = models.URLField(max_length=200, null=True,blank=True)
    def __str__(self):
        return self.name




