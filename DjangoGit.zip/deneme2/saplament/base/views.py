from django.utils import timezone
from django.db.models import Count

from django.db.models import Sum
import re
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from django.contrib import messages

from django.core.paginator import Paginator

from django.contrib.auth.models import User
# Create your views here.
from .models import (
    Products,
    categories,
    Cart,
    CartItem,
    FooterURL,
    Iletisim,
    Hakkimizda,
    Address,
    Order,
    OrderItem,

)


def count(request):
    if request.user.is_authenticated:
        q = CartItem.objects.filter(cart__user=request.user).annotate(Count('quantity'))
        result = 0
        for x in range(0, q.count()):
            res = "".join([ele for ele in str(q[x])[0:3] if ele.isdigit()])
            _int1 = int(res)
            result = result + _int1

    else:
        result = '0'  # burayı düzelt
    return result


def hakkimizda():
    hakkimizda = Hakkimizda.objects.all().values()
    return hakkimizda


def footer():
    footer = FooterURL.objects.all().values()
    return footer


def iletisim():
    iletisim = Iletisim.objects.all().values()
    return iletisim


def index(request):
    product = Products.objects.all().values().order_by('-id')
    category = categories.objects.all().values()
    # template = loader.get_template('index.html')
    toplam = 0
    p = Paginator(product, per_page=10)
    page = request.GET.get('page')
    products = p.get_page(page)

    context = {
        'product': product,
        'products': products,
        'category': category,
        'count': count(request),
        'url': footer(),
        'iletisim': iletisim(),
        'hakkimizda': hakkimizda(),
    }
    return render(request, 'index.html', context)  # HttpResponse(template.render(context,request))


# Category


def category(request, slug):
    product = Products.objects.filter(category__slug=slug).order_by('-id')
    p = Paginator(product, per_page=10)
    page = request.GET.get('page')
    products = p.get_page(page)
    template = loader.get_template('category.html')
    context = {
        'category': categories.objects.all().values(),
        'products': products,
        'url': footer(),
        'iletisim': iletisim(),
        'count': count(request),
    }
    return HttpResponse(template.render(context, request))


@login_required(login_url='login')
def cart(request):
    product = Products.objects.all()
    item = CartItem.objects.filter(cart__user=request.user)

    # quantity_sum=CartItem.objects.filter(user=request.user)
    # print(quantity_sum)# ürünlerin fiyatını topluyor adeti 1 olarak alıyor
    # print(type(quantity_sum))
    price_sum = CartItem.objects.filter(cart__user=request.user).aggregate(
        Sum('total_price')).get('total_price__sum')
    print(price_sum)

    context = {
        'item': item,
        'product': product,
        'url': footer(),
        'iletisim': iletisim(),
        'count': count(request),
        'price_sum': price_sum,
    }
    return render(request, 'apps/cart.html', context)


@login_required(login_url='login')
def add_to_cart(request, slug):
    item = get_object_or_404(Products,slug=slug)
    try:
        cart = Cart.objects.get(user=request.user)
    except Cart.DoesNotExist:
       cart=Cart.objects.create(
           user=request.user,ordered_date=timezone.now()
       )
    cart_item, is_created = CartItem.objects.get_or_create(
        item=item,
        cart=cart,
    )
    if is_created==True:
        messages.info(request, "This item was added to your cart.")
        return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
    if is_created==False:
        cart_item.quantity += 1
        cart_item.total_price = item.price*cart_item.quantity
        cart_item.cart_item_price=item.price
        cart_item.save()
        messages.info(request, "This item was updated")
        return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))









    # if add_to_cart:
    #     order = add_to_cart
    #     # check if the order item is in the order
    #
    #     if CartItem.objects.filter(item__slug=item.slug).exists():
    #         order_item.quantity += 1
    #         order_item.total_price = order_item.quantity * item.price
    #         print(order_item.total_price)
    #         order_item.save()
    #         messages.info(request, "This item quantity was updated.")
    #         return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
    #     else:
    #         print('elseAltı')
    #         order.cart_item.add(order_item)
    #         messages.info(request, "This item was added to your add_to_cart.")
    #         return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
    #


@login_required
def remove_from_cart(request, slug):
    item = get_object_or_404(Products, slug=slug)
    order_qs = Cart.objects.filter(
        user=request.user,
    )
    if order_qs.exists():
        order = order_qs[0]
        # check if the order item is in the order
        if order.items.filter(item__slug=item.slug).exists():
            order_item = CartItem.objects.filter(
                item=item,
                user=request.user,
            )[0]
            order.items.remove(order_item)
            order_item.delete()
            messages.info(request, "This item was removed from your cart.")
            return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
        else:
            messages.info(request, "This item was not in your cart")
            return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.info(request, "You do not have an active order")
        return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))


@login_required
def remove_single_item_from_cart(request, slug):
    item = get_object_or_404(Products, slug=slug)
    order_qs = Cart.objects.filter(
        user=request.user,
    )
    if order_qs.exists():
        order = order_qs[0]
        # check if the order item is in the order
        if CartItem.objects.filter(item__slug=item.slug).exists():
            order_item = CartItem.objects.filter(
                item=item,
            )[0]
            if order_item.quantity > 1:
                order_item.quantity -= 1
                order_item.total_price = order_item.quantity * item.price
                order_item.save()
            else:
                order.items.remove(order_item)
            messages.info(request, "This item quantity was updated.")
            return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
        else:
            messages.info(request, "This item was not in your cart")
            return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
    else:
        messages.info(request, "You do not have an active order")
        return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))


def deleteCart(request, slug):
    product = Products.objects.get(slug=slug)
    cart_item = CartItem.objects.filter(item=product)
    cart_item.delete()
    return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))


def order(request):
    try:
        cart_item = CartItem.objects.filter(cart__user=request.user)
        order=Order.objects.get(user=request.user)
        cart=Cart.objects.get(user=request.user)
        price_sum=cart_item.aggregate(
            Sum('total_price')).get('total_price__sum')
        order_item = OrderItem.objects.get(order__user=request.user)


    except Order.DoesNotExist:
        order=Order.objects.create(
            user=request.user
        )

    except OrderItem.DoesNotExist:
        order_item=OrderItem.objects.create(
            cart=cart,
            order=order,
        )

    except CartItem.DoesNotExist:
        messages.WARNING(request, "You do not have an active order")

    if request.method == 'POST':
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        phone_no=request.POST['phone_no']
        _address=request.POST['address']
        city=request.POST['city']
        region=request.POST['region']
        zip_code=request.POST['zip-code']
        country=request.POST['country']
        user = User.objects.get(username=request.user)
        user.first_name = first_name
        user.last_name = last_name
        user.save()
        if not Address.objects.filter(user=user).exists():
            address,is_created = Address.objects.get_or_create(
                user=user,
                phone=phone_no,
                address=_address,
                city=city,
                region=region,
                zip_code=zip_code,
                country=country,
            )
            if is_created == True:
                messages.info(request, "Adres kaydedildi")
                return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))

        else:

            address= Address.objects.get(user=user)
            address.phone=phone_no
            address.address=_address
            address.city=city
            address.region=region
            address.zip_code=zip_code
            address.country=country
            address.save()
            messages.info(request, "adres güncellendi")
            return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))




    try:
        address=Address.objects.get(
            user=request.user,
        )
        context = {
            'address':Address.objects.get(user=request.user),

        }
        return render(request, 'apps/order-summary.html', context)

    except Address.DoesNotExist:
        context = {
            'price_sum': price_sum
        }
        return render(request, 'apps/order-index.html', context)


def order_summary(request):
    context = {

    }

    return render(request, 'apps/order-summary.html', context)

# def product_update(request):
#     product = Products.objects.all().values()
#     template = loader.get_template('apps/product-update.html')
#     context = {
#         'product': product,
#     }
#     return HttpResponse(template.render(context, request))

# def table(request):
#     product = products.objects.all().values()
#     category= categories.objects.all().values()
#     template= loader.get_template('apps/table.html')
#     context = {
#         'product': product, 'category':category
#     }
#     return HttpResponse(template.render(context,request))


# def dashboard(request):
#     template = loader.get_template('dashboard/dashboard.html')
#     context={
#     }
#     return HttpResponse(template.render(context,request))


# #Productt


# def add(request):
#     template = loader.get_template('apps/add.html')
#     return HttpResponse(template.render({},request))


# def addRecord(request):
#     urunAdi= request.POST['urunAdi']
#     urunFiyat = request.POST['urunFiyat']
#     categoryID= request.POST['categoryID']
#     urunDesc = request.POST['urunDesc']
#     urunFoto = request.POST['urunFoto']
#     #foto copy
#     path="C:\\Users\\mehme\\Desktop\\fotoEkleme\\"+urunFoto
#     destination ="C:\\Users\\mehme\\Desktop\\djangoDeneme\\saplament\\base\\static\\images\\"+urunFoto
#     shutil.copyfile(path,destination)

#     product = products(
#         urun_adi=urunAdi,
#         urun_fiyat=urunFiyat,
#         category_name=categoryID,
#         urun_desc=urunDesc,
#         urun_foto=urunFoto

#     )
#     product.save()
#     messages.info(request, 'Added successfully!')
#     return HttpResponseRedirect(reverse('add'))

# def update(request,id):
#     product = products.objects.get(id=id)
#     template = loader.get_template('apps/update.html')
#     context = {
#         'product':product
#     }
#     return HttpResponse(template.render(context,request))

# def updateRecord(request,id):

#     product = products.objects.get(id=id)
#     urunAdi=request.POST['urunAdi']
#     urunFiyat=request.POST['urunFiyat']
#     urunCategory=request.POST['categoryID']
#     urunDesc=request.POST['urunDesc']
#     urunFoto= request.POST['urunFoto']
#     product.urun_adi=urunAdi
#     product.urun_fiyat=urunFiyat
#     product.category_name=urunCategory
#     product.urun_desc = urunDesc
#     product.urun_foto=urunFoto
#     try:
#     #copy foto
#         path="C:\\Users\\mehme\\Desktop\\fotoEkleme\\"+urunFoto
#         destination ="C:\\Users\\mehme\\Desktop\\djangoDeneme\\saplament\\base\\static\\images\\"+urunFoto
#         shutil.copyfile(path,destination)
#     except:
#         print('')
#     product.save()
#     return HttpResponseRedirect(reverse('index'))


# def delete(request,id):
#     product = products.objects.get(id=id)
#     product.delete()
#     return HttpResponseRedirect(reverse('table'))


# def addCategory(request):
#     template = loader.get_template('apps/add-category.html')
#     return HttpResponse(template.render({},request))


# def addCategoryRecord(request):
#     categoryName= request.POST['categoryName']
#     category = categories(
#         category_name=categoryName

#     )
#     category.save()
#     return HttpResponseRedirect(reverse('table'))

# def categoryUpdate(request,id):
#     category = categories.objects.get(id=id)
#     template = loader.get_template('apps/update-category.html')
#     context = {
#         'category':category
#     }
#     return HttpResponse(template.render(context,request))


# def categoryUpdateRecord(request,id):
#     category = categories.objects.get(id=id)
#     catID = request.POST['catID']
#     categoryName=request.POST['categoryName']
#     category.delete()
#     category.category_name=categoryName
#     category.id=catID
#     category.save()
#     return HttpResponseRedirect(reverse('table'))


# def categoryDelete(request,id):
#     category = categories.objects.get(id=id)
#     category.delete()
#     return HttpResponseRedirect(reverse('table'))




